August 6, 2012

README: RxNorm 8/6/2012 Full Update Release
===================================================

-----------------------------------------------------------------
This Full release contains data that is consistent with the 
2012AA version of the UMLS.   
-----------------------------------------------------------------

This release contains updates to the following seven sources: 

GS - 07/05/2012 (Gold Standard Alchemy) 
MDDB - 07/04/2012 (Master Drug Data Base. Medi-Span, a division of Wolters Kluwer Health) 
MMSL - 07/01/2012 (Multum MediSource Lexicon) 
MMX - 07/02/2012 (Micromedex DRUGDEX)  
MTHSPL - 07/30/2012 (FDA Structured Product Labels) 
NDDF - 07/11/2012 (First Databank FDB MedKnowledge (formerly NDDF Plus))
VANDF - 06/27/2012 (Veterans Health Administration National Drug File)

For full details, please refer to the RxNorm documentation at 
http://www.nlm.nih.gov/research/umls/rxnorm/docs/index.html.  

This release contains database control files and SQL
commands for use in the automation of the loading process of
these files into an Oracle RDBMS.  In addition, scripts are now 
provided for loading the RxNorm files into a MySQL database.
 
RxNorm release data files are available by download from
the NLM download server at:

        http://www.nlm.nih.gov/research/umls/rxnorm/docs/rxnormfiles.html

This link will take you to a page for downloading the latest files:
RxNorm_full_08062012.zip

Once downloaded, it must be unzipped in order to access the files.

HARDWARE AND SOFTWARE RECOMMENDATIONS
-------------------------------------
- Supported operating systems:
	Windows: XP, 2000, NT
	Linux
	Solaris: Solaris 8 and 9 
      Macintosh OS 9 or OS 10 

- Hardware Requirements

  - A MINIMUM 1.1 GB of free hard disk space (To accomodate ZIP files and 
	unzipped contents).  


CONTENTS OF THE ZIP FILE
-------------------------

The ZIP formatted file is 137,130,050 bytes and contains the 
following 59 files and 14 directories:

	Readme_Full_08062012.txt	4,715	bytes

rrf directory:

	RXNCONSO.RRF			101,133,598	bytes
	RXNDOC.RRF			182,125		bytes
	RXNREL.RRF			213,468,187	bytes
	RXNSAB.RRF			8,236		bytes		
	RXNSAT.RRF			392,284,234	bytes 
	RXNSTY.RRF			15,449,456	bytes
	RXNATOMARCHIVE.RRF		44,636,408	bytes
	RXNCUICHANGES.RRF		139,316		bytes
	RXNCUI.RRF		      	895,312		bytes

scripts directory:

	oracle sub-directory:

	RXNATOMARCHIVE.ctl		564		bytes
	RXNCONSO.ctl			512		bytes
	RXNCUI.ctl			296		bytes
	RXNCUICHANGES.ctl		346		bytes
	RXNDOC.ctl			248		bytes
	RXNREL.ctl			471		bytes
	RXNSAB.ctl			674		bytes	
	RXNSAT.ctl			378		bytes
	RXNSTY.ctl			267		bytes
	RxNormDDL.sql			3,291		bytes
	rxn_index.sql			660		bytes
	populate_oracle_rxn_db.bat	1,164		bytes

	mysql sub-directory:

	Indexes_mysql_rxn.sql		662		bytes	
	Load_scripts_mysql_rxn_unix.sql	3,961		bytes
	Load_scripts_mysql_rxn_win.sql	3,959		bytes
	Populate_mysql_rxn.bat		777		bytes
	populate_mysql_rxn.sh		1,609		bytes
	Table_scripts_mysql_rxn.sql	4,715		bytes

ocd directory
	
	rrf sub-directory:

	RXNCONSOOCD.RRF			37,025,053	bytes
	RXNSATOCD.RRF			113,051,649	bytes
	RXNSTYOCD.RRF			3,269,055	bytes

	scripts sub-directory:

		oracle sub-directory:

		RXNCONSOOCD.ctl			524		bytes
		RXNSATOCD.ctl			390		bytes
		RXNSTYOCD.ctl			279		bytes
		RxNormDDL.sql			1,104		bytes
		rxn_index.sql			363		bytes
		populate_oracle_rxn_db.bat	708		bytes

		mysql sub-directory:

		Indexes_mysql_rxn.sql		364		bytes	
		Load_scripts_mysql_rxn_unix.sql	1,224		bytes
		Load_scripts_mysql_rxn_win.sql	1,223		bytes
		Populate_mysql_rxn.bat		777		bytes
		populate_mysql_rxn.sh		1,609		bytes
		Table_scripts_mysql_rxn.sql	1,545		bytes

prescribe directory

	Readme_Full_Prescribe_08062012.txt	2,656	bytes
	
	rrf subdirectory:
	
	RXNCONSO.RRF			15,552,718	bytes
	RXNREL.RRF			45,711,030	bytes
	RXNSAT.RRF			46,244,939	bytes

	scripts sub-directory:

		oracle sub-directory:

		RXNCONSO.ctl			512	bytes
		RXNREL.ctl			471	bytes
		RXNSAT.ctl			378	bytes
		RxNormDDL.sql			1,373	bytes
		rxn_index.sql			460	bytes
		populate_oracle_rxn_db.bat	699	bytes

		mysql sub-directory:

		Indexes_mysql_rxn.sql		463	bytes	
		Load_scripts_mysql_rxn_unix.sql	1,469	bytes
		Load_scripts_mysql_rxn_win.sql	1,468	bytes
		Populate_mysql_rxn.bat		777	bytes
		populate_mysql_rxn.sh		1,609	bytes
		Table_scripts_mysql_rxn.sql	1,749	bytes

	
Additional NOTES:
-----------------

- Most RxNorm users will need applications and data management
  systems such as an RDBMS for storage and retrieval.

- The RxNorm release files contain UTF-8 Unicode encoded data.

- Refer to the RxNorm release documentation at http://www.nlm.nih.gov/research/umls/rxnorm/docs/index.html 
  for information on the contents of the RxNorm Release Files
