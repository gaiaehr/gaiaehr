create index x_rxnconsoocd_str on rxnconsoocd(str);
create index x_rxnconsoocd_rxcui on rxnconsoocd(rxcui);
create index x_rxnconsoocd_tty on rxnconsoocd(tty);
create index x_rxnconsoocd_code on rxnconsoocd(code);
create index x_rxnsatocd_rxcui on rxnsatocd(rxcui);
create index x_rxnsatocd_atv on rxnsatocd(atv);
create index x_rxnsatocd_atn on rxnsaocdt(atn);

